#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <Adafruit_AHTX0.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#include "Adafruit_LTR390.h"

#define SDA_PIN 3
#define SCL_PIN 4

#define BOOT_BUTTON 0   // Built-in BOOT / D0 button

Adafruit_LTR390 ltr;
Adafruit_AHTX0 aht;
Adafruit_BMP280 bmp;
Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST);

// Shows a label and value on the screen
void drawLabelValue(int x, int y, const char *label, String value) {
  tft.setCursor(x, y);
  tft.print(label);
  tft.setCursor(x + 70, y);
  tft.print(value);
}

// Runs once at startup, sets everything up
void setup() {

  Serial.begin(115200);
  delay(1000);

  pinMode(BOOT_BUTTON, INPUT_PULLUP);

  Wire.begin(SDA_PIN, SCL_PIN);

  pinMode(TFT_BACKLITE, OUTPUT);
  digitalWrite(TFT_BACKLITE, HIGH);

  pinMode(TFT_I2C_POWER, OUTPUT);
  digitalWrite(TFT_I2C_POWER, HIGH);

  delay(10);

  tft.init(135,240);
  tft.setRotation(3);
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(1);

  tft.setCursor(10,10);
  tft.println("Starting sensors...");

  bool ahtFound = aht.begin();

  bool bmpFound = false;

  if (bmp.begin(0x76)) {
    bmpFound = true;
  }
  else if (bmp.begin(0x77)) {
    bmpFound = true;
  }

  if (!ltr.begin()) {

    tft.fillScreen(ST77XX_BLACK);

    tft.setCursor(10,20);
    tft.println("LTR390 missing");

    while(1);
  }
  // Ambient light mode
  ltr.setMode(LTR390_MODE_ALS);
  ltr.setGain(LTR390_GAIN_3);
  ltr.setResolution(LTR390_RESOLUTION_16BIT);

  if (!ahtFound || !bmpFound) {

    tft.fillScreen(ST77XX_BLACK);

    tft.setCursor(10,20);
    tft.println("Sensor issue");

    while(1);
  }
  tft.fillScreen(ST77XX_BLACK);
}

// Runs forever, updates sensors and screen
void loop() {
  sensors_event_t humidity, ahtTemperature;

  // reads and extracts the values from the different sensors
  aht.getEvent(&humidity, &ahtTemperature);

  float bmpTemperature = bmp.readTemperature();
  float pressure = bmp.readPressure() / 100.0F;

  uint32_t light = 0;
  if (ltr.newDataAvailable()) {
    light = ltr.readALS();
  }

  tft.fillScreen(ST77XX_BLACK);
  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(1);

  // this is the code for the built in button on the esp32
  if (digitalRead(BOOT_BUTTON) == LOW) {
    tft.setCursor(10, 50);
    tft.println("Todays Weather Report");

    if (ahtTemperature.temperature < 19.0 && humidity.relative_humidity > 70.0 && light < 200 && pressure < 500.0) {
      tft.setTextColor(ST77XX_RED);
      tft.println("todays weather is cold, humid, cloudy and could be rainy");
    } else if (ahtTemperature.temperature > 19.0 && humidity.relative_humidity < 70.0 && light > 200 && pressure > 500.0) {
      tft.setTextColor(ST77XX_GREEN);
      tft.println("todays weather is warm, dry and sunny");
    } else if (ahtTemperature.temperature < 10.0) {
      tft.setTextColor(ST77XX_BLUE);
      tft.println("todays weather is cold, and could be icy");
    }
  } else {
    tft.setCursor(10, 10);
    tft.println("AHT20");

    drawLabelValue(10, 20, "Temp:", String(ahtTemperature.temperature, 1) + " C");
    drawLabelValue(10, 30, "Hum :", String(humidity.relative_humidity, 1) + " %");

    tft.setCursor(10, 50);
    tft.println("BMP280");

    drawLabelValue(10, 65, "Temp:", String(bmpTemperature, 1) + " C");
    drawLabelValue(10, 75, "Pres:", String(pressure, 1) + " hPa");

    tft.setCursor(10, 95);
    tft.println("LTR390");
    drawLabelValue(10, 105, "Light:", String(light));
  }

  delay(200);
}